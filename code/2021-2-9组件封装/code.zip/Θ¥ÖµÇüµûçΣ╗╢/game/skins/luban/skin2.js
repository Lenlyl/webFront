export default class Skin2{
    constructor(){
        this.name = "皮肤二";
        this.ico = "./sources/heroes/luban2.png";
        this.img = "./sources/skins/301121.png"
    }
}