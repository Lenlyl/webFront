<template>
  <div>
    <user-form></user-form>
  </div>
</template>

<script>
import UserForm from "../components/UserForm";

export default {
  components: {
    UserForm,
  },
};
</script>

<style></style>
