import { useState,useMemo,useCallback } from "react";
function App() {
    const [count, setCount] = useState(1);
    const [nub, setNub] = useState(1);
    const nub2 = useMemo(()=>{
        console.log("111");
        return nub*3
    },[nub]);
    // const getNubCube = useMemo(()=>{
    //     console.log("222");
    //     return ()=>{
    //         alert(nub*nub);
    //     }
    // },[nub]); 
    const  getNubCube = useCallback(() => {
        alert(nub*nub);
    },[nub]);
    return (
        <>
            <p>{count}</p>
            <button onClick={() => {
                setCount(count + 1)
            }}>count-递增</button>
            <p>{nub}</p>
            <p>{nub2}</p>
            <button onClick={() => {
                setNub(nub + 1)
            }}>nub-递增</button>
            <button onClick={getNubCube}>获取nub立方</button>
        </>
    );
}
export default App;
