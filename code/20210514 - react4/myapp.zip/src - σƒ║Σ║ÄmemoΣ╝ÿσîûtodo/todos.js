import Todo from "./todo";

export default function ({data,...props}) {
    return <ul id="todo-list">
        {
            data.map(item => <Todo key={item.id} {...props} data={item} />)
        }
    </ul>
}
