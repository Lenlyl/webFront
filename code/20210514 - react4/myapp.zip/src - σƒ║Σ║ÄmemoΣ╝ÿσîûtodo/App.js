import { useState } from "react";
import CreateTodo from "./createTodo";
import Stats from "./stats";
import Todos from "./todos";
/*
    App 挂载时，会产生一个闭包
        该闭包，声明了一个常量 todos，及一些列操作 todos 的方法
        [
            {
                id: 1,
                done: false
            }, {
                id: 2,
                done: true
            }
        ]
    App 更新时，会产生一个新的闭包
        该闭包，声明了一个常量 todos，及一些列操作 todos 的方法
        [
            {
                id: 1,
                done: true
            }, {
                id: 2,
                done: true
            }
        ]
    App 再次更新时，会产生一个新的闭包
        该闭包，声明了一个常量 todos，及一些列操作 todos 的方法
        [
            {
                id: 1,
                done: false
            }, {
                id: 2,
                done: false
            }
        ]

*/
function App() {
    const [todos, setTodos] = useState({
        todos: [{
            id: 1,
            todo: "向老婆申请一笔皮肤经费",
            done: false
        }, {
            id: 2,
            todo: "晚上吃烧烤",
            done: true
        }]
    });
    const addTodo = (todo) => {
        todos.todos.unshift({
            id: Date.now(),
            todo,
            done: false
        })
        setTodos({
            todos: todos.todos
        })
    }
    const changeDone = (id, done) => {
        todos.todos.forEach((item, index) => {
            if (id === item.id) {
                todos.todos[index] = {
                    ...item,
                    done
                }
            }
        });
        setTodos({
            todos: todos.todos
        })
    }
    const editTodo = (id, todo) => {
        todos.todos.forEach((item, index) => {
            if (id === item.id) {
                todos.todos[index] = {
                    ...item,
                    todo
                }
            }
        });
        setTodos({
            todos: todos.todos
        })
    }
    const removeTodo = (id) => {
        let index = todos.todos.findIndex(item=>item.id===id);
        todos.todos.splice(index,1);
        setTodos({
            todos:todos.todos
        })
    }
    return <div id="todoapp">
        <div className="title">
            <h1>todo</h1>
        </div>
        <div
            className="content"
        >
            <CreateTodo
                addTodo={addTodo}
            />
            {todos.todos.length > 0 ? <>
                <Todos
                    data={todos.todos}
                    changeDone={changeDone}
                    removeTodo={removeTodo}
                    editTodo={editTodo}
                />,
                    <Stats
                    data={todos.todos}
                />
            </> : ""}

        </div>
    </div>
}
export default App;
