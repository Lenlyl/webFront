import { useState,useRef,useEffect, memo } from "react";
function Todo({ data, changeDone, removeTodo, editTodo }) {
    const { id, todo, done } = data;
    const [isEdit, setIsEdit] = useState(false);
    const [todoText, setTodoText] = useState(todo);
    const editText = useRef();
    useEffect(() => {
        if (isEdit) {
            editText.current.focus()
        }
    }, [isEdit]);
    console.log(id,"render");
    return <li
        className={isEdit ? "editing" : ""}
    >
        <div className={`todo ${done ? "done" : ""}`}>
            <div className="display">
                <input
                    className="check"
                    type="checkbox"
                    checked={done}
                    onChange={({ target }) => {
                        changeDone(id, target.checked)
                    }}
                />
                <div
                    className="todo-content"
                    onDoubleClick={() => {
                        setIsEdit(true);
                    }}
                >{todo}</div>
                <span
                    className="todo-destroy"
                    onClick={() => {
                        removeTodo(id);
                    }}
                ></span>
            </div>
            <div className="edit">
                <input
                    className="todo-input"
                    type="text"
                    ref={editText}
                    value={todoText}
                    onChange={({ target }) => {
                        setTodoText(target.value);
                    }}
                    onBlur={() => {
                        if (todoText.trim()) {
                            editTodo(id, todoText);
                        } else {
                            setTodoText(todo);
                        }
                        setIsEdit(false);
                    }}
                />
            </div>
        </div>
    </li>
}

export default memo(Todo,(props,nextProps)=>{
    return props.data === nextProps.data;
});
