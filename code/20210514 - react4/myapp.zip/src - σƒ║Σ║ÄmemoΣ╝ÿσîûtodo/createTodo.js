import { Component } from "react";
export default function ({addTodo}){
    return <div id="create-todo">
            <input
                id="new-todo"
                placeholder="What needs to be done?"
                autoComplete="off"
                type="text"
                onKeyDown={({keyCode,target})=>{
                    if(keyCode === 13){
                        if(target.value.trim()){
                            addTodo(target.value);
                            target.value = ""
                        } else {
                            alert("请输入 todo")
                        }
                    }
                }}
            />
        </div>
}
