import { useState } from "react";
import Child from "./nub";
function App() {
    const [nub, setNub] = useState(1);
    const [count, setCount] = useState(10);
    return <>
        <Child data={nub} setData={setNub} name="nub" />
        <Child data={count} setData={setCount} name="count" />
    </>
}
export default App;
