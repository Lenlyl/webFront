import {memo} from "react"
function Child({data,setData,name}){
    console.log(name,"render");
    return <div>
        <p>{data}</p>
        <button onClick={()=>{
            setData(data+1);
        }}>递增</button>
    </div>
}
/*
    memo 高阶组件：高阶组件是一个正常函数，该函数接收一个组件，并且返回一个新组件
    - 当 memo 返回组件被调用时，memo 会调用我们传入的组件
    - 当 memo 的返回组件被更新时，memo 会调用 调和函数，并传入 props 和 nextProps。如果调和函数的返回值为 false 则更新传入的组件，否则不更新传入的组件
*/
const NewChild = memo(Child,(props,nextprops)=>{
    //console.log(props,nextprops);
    return props.data === nextprops.data;
});
export default NewChild;
