import {useState} from "react";
import Child from "./child";
/*
  hooks 使用注意事项:
  1. hooks 只能在 react 函数(函数组件，自定义hook)中调用
  2. hooks 在使用时，要保持调用顺序,不能将 hooks 包括在 流程控制语句中，也不能将 hooks 包括在子函数中。
*/
function App() {
  const [show,changeShow] = useState(true);
  return <>
    {show?<Child />:""}
    <button onClick={()=>{
      changeShow(!show);
    }}>显示隐藏</button>
  </>
}

export default App;
