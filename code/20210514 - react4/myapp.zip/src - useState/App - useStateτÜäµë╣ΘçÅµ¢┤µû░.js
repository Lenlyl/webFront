import {useState} from "react";
/*
  useState 的 setState 和 class 的 setState 之间的区别:
  1. useState的setState()只接收一个参数，就是更新后的 state
  2. useState 的 setState 同样受到批量更新机制的影响
  3. useState 的 setState,不会进行浅合并

  函数组件更新：把函数重新执行一遍
*/
function App() {
  const [count,setCount] = useState(1);
  const [nub,setNub] = useState(1);
  console.log("render");
  return (
    <>
      <p>{count}</p>
      <button onClick={()=>{
        setCount(count + 1)
      }}>count-递增</button>
      <p>{nub}</p>
      <button onClick={()=>{
        setNub(nub + 1)
      }}>nub-递增</button>
      <button onClick={()=>{
        setCount(count + 1);
        setNub(nub + 1);
        //console.log(count,nub);
      }}>批量-递增</button>
    </>
  );
}

export default App;
