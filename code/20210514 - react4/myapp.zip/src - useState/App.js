import {useState} from "react";
/*
  useState 的 setState 和 class 的 setState 之间的区别:
  1. useState的setState()只接收一个参数，就是更新后的 state
  2. useState 的 setState 同样受到批量更新机制的影响
  3. useState 的 setState,不会进行浅合并

  函数组件更新：把函数重新执行一遍
*/
function App() {
  const [state,setState] =  useState({
    nub: 1,
    count: 1
  });
  const {nub,count} = state;
  return (
    <>
      <p>{count}</p>
      <button onClick={()=>{
        setState({
          nub,
          count: count + 1
        });
      }}>count-递增</button>
      <p>{nub}</p>
      <button onClick={()=>{
         setState({
          nub: nub + 1,
          count
        });
      }}>nub-递增</button>
    </>
  );
}

export default App;
