import { useState, useEffect } from "react";
/*
    useEffect：副作用钩子，在函数组件中用于替代调生命周期函数（ componentDidMount、componentDidUpdate 和 componentWillUnmount）
    useEffect(()=>{
        //副作用函数 effect
        return ()=>{ 
            返回函数 cleanup
        }
    },[input]依赖参数)

    挂载阶段:
        从上到下执行函数,如果遇到 useEffect，会将 effect 函数，推入一个队列，在组件挂载完成之后，找到  effect 函数 的队列，然后按照顺序依次执行 effect 函数，并获取 effect 中的 cleanup 函数，推入一个队列
    更新阶段:
        从上到下执行函数,如果遇到 useEffect，会将 effect 函数，推入一个队列，在组件挂载完成之后，找到 cleanup 函数队列，依次执行,然后按照顺序依次执行 effect 函数，并获取 effect 中的 cleanup 函数，推入一个队列。
        **在更新阶段，执行cleanup 函数和effect 函数会观察对应的 依赖参数有没有修改，有修改才执行*
    卸载阶段：
        即将卸载组件时，执行 cleanup队列。

    依赖参数：
        为空, 什么都不写，代表依赖所有值，每次函数更新时，cleanup 函数 和 effect 函数 都执行
        为[], 代表不依赖任何值，则只在挂载之后执行  effect 函数，在卸载时，执行 cleanup 函数
        [具体值], 更新阶段只在依赖值有变化时，执行cleanup 函数 和 effect 函数

*/
function Child() {
    const [count, setCount] = useState(1);
    const [nub, setNub] = useState(1);
    useEffect(() => {
        console.log("didMount");
        return ()=>{
            console.log("willUnMount");
        }
    }, []);
    useEffect(() => {
        console.log("didMount和didUpdate");
    })
    return (
        <>
            <p>{count}</p>
            <button onClick={() => {
                setCount(count + 1)
            }}>count-递增</button>
            <p>{nub}</p>
            <button onClick={() => {
                setNub(nub + 1)
            }}>nub-递增</button>
        </>
    );
}

export default Child;
