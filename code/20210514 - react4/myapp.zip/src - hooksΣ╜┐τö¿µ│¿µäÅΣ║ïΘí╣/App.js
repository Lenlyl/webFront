import {useState} from "react";
/*
  hooks 使用注意事项:
  1. hooks 只能在 react 函数(函数组件，自定义hook)中调用
  2. hooks 在使用时，要保持调用顺序,不能将 hooks 包括在 流程控制语句中，也不能将 hooks 包括在子函数中。
*/
function App() {
  const [count,setCount] = useState(1);
  const [nub,setNub] = useState(1);
  return (
    <>
      <p>{count}</p>
      <button onClick={()=>{
        setCount(count + 1)
      }}>count-递增</button>
      <p>{nub}</p>
      <button onClick={()=>{
        setNub(nub + 1)
      }}>nub-递增</button>
    </>
  );
}

export default App;
