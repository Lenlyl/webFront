import { Component } from "react";
/*
组件：组件化创建拥有各自状态的组件，再由这些组件构成更加复杂的 UI
  - 类组件
      1. 初始化组件（声明组件）
        - 在 React 中，所有的类组件都必须继承自 Component
        - 在类组件中，必须有一个 render 方法，render 方法的返回值，代表该组件要输出的视图
      2. 调用组件 <组件名/> || createElement(组件名)
  - 函数组件
*/



class App extends Component {
  render(){
    return <h1>hello</h1>
  }
}

export default App;