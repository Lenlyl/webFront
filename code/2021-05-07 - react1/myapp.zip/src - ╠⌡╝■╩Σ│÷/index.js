import React,{Fragment} from "react";
import ReactDOM from "react-dom";
/*
条件输出:
  - ||、&&、:?
  - 函数调用
列表输出：

*/
let fn = (nub)=>{
  if(nub < 5){
    return "小于5"
  }
  if(nub < 10){
    return "小于10"
  }
  if(nub < 20){
    return "小于20"
  }
  return "大于等于20"
}
let inner = <>
  <div>{true&&"成立"}</div>
  <div>{false||"不成立"}</div>
  <div>{false?"成立":"不成立"}</div>
  <div>{fn(8)}</div>
</>;


ReactDOM.render(
  inner,
  document.querySelector("#root")
);