import React, { Fragment } from "react";
import ReactDOM from "react-dom";
/*
  特殊属性:
    1. 属性名称由多个单词组成: 从第二个单词开始，首字母大写(data 自定义属性除外)
    2. style 的值是一个对象
    3. 属性值除了字符串之外，都得用插值
*/
let data = ["列表项-a", "列表项-b", "列表项-c"];
// let style = {
//   width: "300px",
//   border: "2px solid #000"
// }
// let inner = <ul style={style}>
//   {data.map((item, index) => {
//     return <li key={index}>{item}</li>
//   })}
//   {/* <label htmlFor="text">文本</label>
//   <input type="text" id="text"/> */}
// </ul>;
let inner = <ul style={{
  width: "300px",
  border: "2px solid #000"
}}>
  {data.map((item, index) => {
    return <li key={index}>{item}</li>
  })}
</ul>;


ReactDOM.render(
  inner,
  document.querySelector("#root")
);