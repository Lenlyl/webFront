import React,{Fragment} from "react";
import ReactDOM from "react-dom";
/*
插值表达式:
  在 JSX 中插入一个 JSX 的表达式
  注意：
    1. JSX 的插值，必须是一个 JS 的表达式
    2. 如何是放在JSX的内容中表达式的值必须是一个 ReactNode
表达式：
  产生值的一个代码组合，比如函数执行、变量、各种运算符
  注意：if、for 、while 等代码执行，不产生值 -- 语句 

ReactNode 都包括什么：(不同数据类型在作为 React Child 时会被怎么输出)
1. 注释 
2. 基础类型 
    - 字符串、数字：原样输出
    - 布尔值、空、未定义、symbol 会被忽略
3. 复杂类型
    - 数组：数组展开后直接输出
    - React 的虚拟DOM
4. 其他报错 
*/
let data = <h1>hello</h1>;
let inner = <div>{data}</div>;


ReactDOM.render(
  inner,
  document.querySelector("#root")
);