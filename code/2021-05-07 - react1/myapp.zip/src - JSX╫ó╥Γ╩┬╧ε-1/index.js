import React,{Fragment} from "react";
import ReactDOM from "react-dom";
/*
JSX 是一个基于 JavaScript + XML 的一个扩展语法
    - 它可以作为值使用 - JSX 必须有一个顶层的包含容器
        1. Fragment - 包含容器，不会在真正的DOM解析出来
        2. <></> - 包含容器，空标签 *17*
    - 它并不是字符串
    - 它也不是HTML
    - 它可以配合 JavaScript 表达式一起使用
*/
let inner = <>
  <header className="header">
    <h1 id="logo">hello react</h1>
    <p className="subTitle">React 的第一节课 - <a href="https://react.docschina.org/">参考手册</a></p>
  </header>
  <ul>
    <li>列表项1</li>
    <li>列表项2</li>
    <li>列表项3</li>
  </ul>
</>;
ReactDOM.render(
  inner,
  document.querySelector("#root")
);