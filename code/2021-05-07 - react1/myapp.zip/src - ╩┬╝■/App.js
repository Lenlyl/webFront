import { Component } from "react";
/*
  事件:
    定义事件：类似于在 JS 中写行间事件，但是要注意事件名从on之后，每个单词首字母大写
    React 中的事件是一种合成事件和原生事件有部分是不同的：
      1. this 指向默认为 undefined
          - 箭头函数，使 this 指向 组件实例
          - this 绑定：使 this 指向 组件实例
      2. 想要获取事件源：
          event.target
      3. 阻止默认事件:
          event.preventDefault();
*/
// class App extends Component {
//   render(){
//     return <>
//         <p>1</p>
//         <button onClick={()=>{
//           console.log(this);
//         }}>计数</button>
//     </>
//   }
// }
class App extends Component {
  constructor(props){
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }
  handleClick(e){
    console.log(this,e);
    e.preventDefault();
  }
  render(){
    return <>
        <p>1</p>
        <a onClick={this.handleClick} href="https://www.baidu.com">计数</a>
    </>
  }
}

export default App;