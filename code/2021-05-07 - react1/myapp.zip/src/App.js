import { Component } from "react";
import "./index.css";
import Menu from "./menu";
import data from "./data";
/*
  1. 写好静态视图
  2. 考虑拆分组件
  3. 绑定数据
  4. 设置状态添加功能
*/
class App extends Component {
  render() {
    return <ul id="menu">
        {Object.keys(data).map(item=>{
          //console.log(item,data[item]);
          return <Menu key={item} title={item} list={data[item]} />
        })}
    </ul>
  }
}

export default App;