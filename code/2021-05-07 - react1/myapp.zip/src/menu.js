import { Component } from "react";
/*
  组件间通信:
    父传子：调用子组件时，将要传递的信息，添加在子组件的属性上，在子组件中，通过 props 属性，接收父组件传递过来的信息 

*/
class Menu extends Component {
  state={
    show: false
  }
  changeShow=()=>{
    const {show} = this.state;
    this.setState({
      show:!show
    });
  }
  render() {
    //console.log(this.props);
    const {title,list} = this.props;
    const {show} = this.state;
    return <li className={show?"subList-show":""}>
      <a onClick={this.changeShow}>{title}</a>
      <ul className="subList">
          {list.map((item,index)=>{
            return <li key={index}>{item}</li>
          })}
      </ul>
    </li>
  }
}
export default Menu;