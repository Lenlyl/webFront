import React,{Fragment} from "react";
import ReactDOM from "react-dom";
/*
条件输出:
  - ||、&&、:?
  - 函数调用
列表输出：
  1. 借助数组
  2. 列表输出时要添加 key
*/
let data = ["列表项-a","列表项-b","列表项-c"];
// let list = [
//   <li>列表项-a</li>,
//   <li>列表项-b</li>,
//   <li>列表项-c</li>
// ]
let list = data.map((item,index)=>{
  return <li key={index}>{item}</li>
})
let inner = <ul>
    {list}
</ul>;


ReactDOM.render(
  inner,
  document.querySelector("#root")
);