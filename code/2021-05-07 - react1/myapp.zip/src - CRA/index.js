import ReactDOM from "react-dom";
/*
  React 17 之后，如果模块中只使用到了 JSX，并没有使用 React 其他方法，可以不引入React依赖
*/
let header = <header className="header">
      <h1 id="logo">hello react</h1>
      <p className="subTitle">React 的第一节课 - <a href="https://react.docschina.org/">参考手册</a></p>
  </header>;

ReactDOM.render(
  header,
  document.querySelector("#root"),
  ()=>{
    console.log("挂载完成-虚拟DOM已经生成真实DOM，并添加到DOM树中");
  }
);  