import { Component } from "react";
/*
  state 和 setState
  state: 状态，React 把组件看做是一个状态机，当我们修改组件的状态时，组件会根据状态的变化，更新视图
  setState: 修改组件状态的唯一方式，就是调用 组件的 setState 方法

*/
class App extends Component {
  state={
    count: 1  
  }
  add=()=>{
    const {count} = this.state;
    this.setState({
       count: count + 1
    });
  }
  render(){
    const {count} = this.state;
    return <>
        <p>{count}</p>
        <button onClick={this.add}>递增</button>
    </>
  }
}

export default App;