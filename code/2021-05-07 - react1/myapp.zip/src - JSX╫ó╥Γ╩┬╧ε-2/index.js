import React,{Fragment} from "react";
import ReactDOM from "react-dom";
/*
JSX 注意事项:
    - 它可以作为值使用 - JSX 必须有一个顶层的包含容器
        1. Fragment - 包含容器，不会在真正的DOM解析出来
        2. <></> - 包含容器，空标签 *17*
    - 它并不是字符串
    - 它也不是HTML
      - 尤其注意很多属性的写法不太一样
    - 它可以配合 JavaScript 表达式一起使用
    - 列表渲染时，必须有 key 值
    - 在 jsx 所有标签必须闭合
    - 组件的首字母一定大写，标签一定要小写
*/
let inner = <>
  <header className="header">
    <h1 id="logo">hello react</h1>
    <p className="subTitle">React 的第一节课 <br /> <a href="https://react.docschina.org/">参考手册</a></p>
  </header>
  <ul>
    <li>列表项1</li>
    <li>列表项2</li>
    <li>列表项3</li>
  </ul>
  <ul />
</>;
ReactDOM.render(
  inner,
  document.querySelector("#root")
);