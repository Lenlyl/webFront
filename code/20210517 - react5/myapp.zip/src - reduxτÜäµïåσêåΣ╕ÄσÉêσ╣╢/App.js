import Count from "./count";
import Todo from "./todo";

function App(){
    return <>
        <Count />
        <hr />
        <Todo />
    </>
}

export default App;
