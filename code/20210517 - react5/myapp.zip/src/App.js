import CNode from "./cnode";
import Count from "./count";
import Todo from "./todo";

function App(){
    return <>
        <Count />
        <hr />
        <Todo />
        <hr />
        <CNode />
    </>
}

export default App;
