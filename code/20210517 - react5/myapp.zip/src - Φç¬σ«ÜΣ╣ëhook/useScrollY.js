/*
    自定义 hook： 命名必须以 use 开始
*/

import { useEffect, useState } from "react"

function useScrollY(){
    const [y,setY] = useState(window.scrollY);
    useEffect(()=>{
        setY(window.scrollY);
        window.onscroll = ()=>{
            setY(window.scrollY);
        }
        return ()=>{
            window.onscroll = null;
        }
    },[]);

    return y;
}

export {useScrollY}
