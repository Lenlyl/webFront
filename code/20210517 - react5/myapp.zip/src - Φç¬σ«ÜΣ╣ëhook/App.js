// css in js

import { useScrollY } from "./useScrollY";

function App() {
  const y = useScrollY();
  return (
    <>
    <style>
    {
      `
        .box div {
          margin: 20px;
          width: 200px;
          height: 200px;
          border: 2px solid #000;
          font-sise: 40px;
        }
        .box span {
          position: fixed;
          left: 0;
          top: 50%;
          width: 100px;
          font: 18px/2 "宋体";
          text-align: center;
          background: #000;
          color: #fff;
        }
      `
    }
    </style>
    <div className="box">
        <div>div1</div>
        <div>div2</div>
        <div>div3</div>
        <div>div4</div>
        <div>div5</div>
        <div>div6</div>
        <div>div7</div>
        <div>div8</div>
        <div>div9</div>
        <div>div10</div>
        <span>{y}</span>
    </div>
    </>
  );
}

export default App;
