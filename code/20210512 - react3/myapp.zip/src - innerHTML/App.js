import { Component } from "react";
import Child from "./child";
/*
    React的特殊属性:
        1. children 
        2. dangerouslySetInnerHTML 用于插入 innerHTML
*/
let data = `<h2>innerHTML</h2>`;


class App extends Component {
    render() {
        return <div>
            <Child>
                <h1>这是children</h1>
                <p>通常用于在父级定义子级的部分结构-类似于vue的 solt</p>
            </Child>
            <div dangerouslySetInnerHTML={{
                __html:data
            }}></div>
        </div>
    }
}

export default App;
