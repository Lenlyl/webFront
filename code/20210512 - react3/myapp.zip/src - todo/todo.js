import { createRef, PureComponent } from "react";
/*
    编辑功能：
        1. 双击 todo 进行编辑状态，
        2. 组件会进行更新
        3. 让输入框获得焦点

        编辑框失去焦点时，退出编辑状态

*/
export default class Todo extends PureComponent {
    constructor(props){
        super(props);
        this.state = {
            isEdit: false,
            todoText: props.data.todo // 将 todo 复制一份
        }
    }
    editText = createRef();
    componentDidUpdate(prevProps,prevState){
        if((!prevState.isEdit)&&this.state.isEdit){
            this.editText.current.focus();
        }
    }
    render() {
        const {isEdit,todoText} = this.state;
        const {data,changeDone,removeTodo,editTodo} = this.props;
        const {id,todo,done} = data;
        return <li 
            className={isEdit?"editing":""}
        >
            <div className={`todo ${done?"done":""}`}>
                <div className="display">
                    <input 
                        className="check" 
                        type="checkbox" 
                        checked={done}
                        onChange={({target})=>{
                            changeDone(id,target.checked)
                        }}
                    />
                    <div 
                        className="todo-content"
                        onDoubleClick={()=>{
                            this.setState({
                                isEdit:true
                            });
                        }}
                    >{todo}</div>
                    <span 
                        className="todo-destroy"
                        onClick={()=>{
                            removeTodo(id);
                        }}
                    ></span>
                </div>
                <div className="edit">
                    <input 
                        className="todo-input" 
                        type="text"
                        ref={this.editText} 
                        value={todoText}
                        onChange={({target})=>{
                            //editTodo(id,target.value);
                            this.setState({
                                todoText: target.value
                            })
                        }}
                        onBlur={()=>{
                            if(todoText.trim()){
                                editTodo(id,todoText);
                            } else {
                                this.setState({
                                    todoText: todo
                                })
                            }
                            this.setState({
                                isEdit:false
                            })
                        }}
                    />
                </div>
            </div>
        </li>
    }
}
