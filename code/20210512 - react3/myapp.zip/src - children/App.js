import { Component } from "react";
import Child from "./child";
/*
    React的特殊属性:
        1. children 

*/

class App extends Component {
    render() {
        return <Child>
            <h1>这是children</h1>
            <p>通常用于在父级定义子级的部分结构-类似于vue的 solt</p>
        </Child>
    }
}

export default App;
