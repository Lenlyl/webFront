import { Component } from "react";

class Child extends Component {
    render() {
        const {children} = this.props;
        console.log(children);
        return (
            <div>
                <p>child</p>
                {children}
            </div>
        )
    }
}

export default Child;
