import {useState} from "react";
/*
    类组件的缺点：
        1. this 问题
        2. 逻辑处理极其麻烦
            1) 单纯复用某种逻辑
            2) 逻辑过于麻烦

    hooks（钩子函数）： 在 16.7 中实验性新增 hooks，16.8 定为 正式 API
    内置 hooks：使函数组件，可以拥有和 类组件一样丰富的功能
        useState 状态

*/
function App(props){
    const [count, setCount] = useState(0);
    const [nub, setNub] = useState(10);
    const [name,setName] = useState("");
    return <div>
        <h2>初窥 hooks</h2>
        <div>{count} - <button onClick={()=>{setCount(count + 1)}}>自增</button></div>
        <div>{nub} - <button onClick={()=>{setNub(nub + 5)}}>自增</button></div>
        <div>
            <input type="text" value={name} onChange={({target})=>{setName(target.value)}} />
            <p>{name}</p>
        </div>
    </div> 
}

export default App;
