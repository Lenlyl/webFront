import { createRef, PureComponent } from "react";
/*
    编辑功能：
        1. 双击 todo 进行编辑状态，
        2. 组件会进行更新
        3. 让输入框获得焦点

        编辑框失去焦点时，退出编辑状态

    React - ref 属性: 用于获取元素实例(如果是组件，获取的就是实例，如果是元素获取的就是DOM)
    ref 的值：
        1. function: 在实例化组件或创建DOM节点是，会调用该 func，并将实例传给 func
        2. ref 对象：会将实例保存如 ref 对象中 

*/
export default class Todo extends PureComponent {
    state={
        isEdit:false
    }
    editText = createRef();
    todoWrap = createRef();
    componentDidMount(){
        //console.log(this.editText,this.todoWrap);
    }
    componentDidUpdate(prevProps,prevState){
        //console.log(prevState.isEdit === false,this.state.isEdit === true);
        if((!prevState.isEdit)&&this.state.isEdit){
            this.editText.current.focus();
        }
    }
    render() {
        const {isEdit} = this.state;
        const {data,changeDone,removeTodo} = this.props;
        const {id,todo,done} = data;
        return <li 
            className={isEdit?"editing":""}
            ref={this.todoWrap}
        >
            <div className={`todo ${done?"done":""}`}>
                <div className="display">
                    <input 
                        className="check" 
                        type="checkbox" 
                        checked={done}
                        onChange={({target})=>{
                            changeDone(id,target.checked)
                        }}
                    />
                    <div 
                        className="todo-content"
                        onDoubleClick={()=>{
                            // this.setState({
                            //     isEdit:true
                            // },()=>{
                            //     this.editText.current.focus();
                            // })
                            this.setState({
                                isEdit:true
                            });
                        }}
                    >{todo}</div>
                    <span 
                        className="todo-destroy"
                        onClick={()=>{
                            removeTodo(id);
                        }}
                    ></span>
                </div>
                <div className="edit">
                    <input 
                        className="todo-input" 
                        type="text"
                        ref={this.editText} 
                        onBlur={()=>{
                            this.setState({
                                isEdit:false
                            })
                        }}
                    />
                </div>
            </div>
        </li>
    }
}
