import { Component } from "react";
/*
    在 React 中，父组件更新，默认情况下一定会引起子组件更新


    let nextProps: 组件更新之后的 props
    let nextState：组件更新之后的 state
    shouldComponentUpdate(nextProps,nextState){
        this.props：组件更新之前的 props
        this.state： 组件更新之前的 state

        nextProps: 组件更新之后的 props
        nextState：组件更新之后的 state
    }
    let prevProps = this.props
    let prevState = this.state;
    this.props = nextProps
    this.state = nextState
    render();
    componentDidUpdate(prevProps,prevState){

    }  

*/
export default class Todo extends Component {
    shouldComponentUpdate(nextProps){
        //console.log(nextProps,this.props);
        return nextProps.data !== this.props.data;  
    }
    
    render() {
        const {data,changeDone,removeTodo} = this.props;
        const {id,todo,done} = data;
        console.log(id,"render");
        return <li className="">
            <div className={`todo ${done?"done":""}`}>
                <div className="display">
                    <input 
                        className="check" 
                        type="checkbox" 
                        checked={done}
                        onChange={({target})=>{
                            changeDone(id,target.checked)
                        }}
                    />
                    <div className="todo-content">{todo}</div>
                    <span 
                        className="todo-destroy"
                        onClick={()=>{
                            removeTodo(id);
                        }}
                    ></span>
                </div>
                <div className="edit">
                    <input className="todo-input" type="text" />
                </div>
            </div>
        </li>
    }
}
