import { Component } from "react";
import Todo from "./todo";
/*
    key: 身份id
*/
/*
    虚拟DOM：
       prev:[a(0),b(1),c(2)]
       next:[c(2),d(3),b(1)] 
*/
/*
    key 取值原则：
    1. 在同一个列表 key 不能重复
    2. 同一个元素更新前后 key 要保持不变
*/
/*
    React.createElement(
        Todo,
        {
            key: id,
            ...this.props,  
            data: item 
        }
    )
*/
export default class Todos extends Component {
    render() {
        const {data} = this.props;
        return <ul id="todo-list">
            {
                data.map(item=><Todo key={item.id} {...this.props} data={item}  />)
            }
        </ul>
    }
}
