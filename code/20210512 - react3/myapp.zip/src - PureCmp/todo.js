import { PureComponent } from "react";
/*
    PureComponent:
        1. PureComponent 和 Component 功能基本一致，但是 PureComponent 自带了一个浅对比的 shouldComponentUpdate 
        会自动浅对比 state 和 props
        2. 使用 PurComponent 不能再次定义 shouldComponentUpdate，否则会破坏掉 PurComponent 的作用
*/
export default class Todo extends PureComponent {
    render() {
        const {data,changeDone,removeTodo} = this.props;
        const {id,todo,done} = data;
        console.log(id,"render");
        return <li className="">
            <div className={`todo ${done?"done":""}`}>
                <div className="display">
                    <input 
                        className="check" 
                        type="checkbox" 
                        checked={done}
                        onChange={({target})=>{
                            changeDone(id,target.checked)
                        }}
                    />
                    <div className="todo-content">{todo}</div>
                    <span 
                        className="todo-destroy"
                        onClick={()=>{
                            removeTodo(id);
                        }}
                    ></span>
                </div>
                <div className="edit">
                    <input className="todo-input" type="text" />
                </div>
            </div>
        </li>
    }
}
