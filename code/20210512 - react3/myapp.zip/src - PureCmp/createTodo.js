import { Component } from "react";

export default class CreateTodo extends Component {
    render() {
        const { addTodo } = this.props;
        return <div id="create-todo">
            <input
                id="new-todo"
                placeholder="What needs to be done?"
                autoComplete="off"
                type="text"
                onKeyDown={({keyCode,target})=>{
                    if(keyCode === 13){
                        //console.log("回车");
                        if(target.value.trim()){
                            addTodo(target.value);
                            target.value = ""
                        } else {
                            alert("请输入 todo")
                        }
                    }
                }}
            />
        </div>
    }
}
