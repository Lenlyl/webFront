import { Component } from "react";
import CreateTodo from "./createTodo";
import Stats from "./stats";
import Todos from "./todos";

class App extends Component {
    state = {
        todos: [
            {
                id: 1,
                todo: "向老婆申请一笔皮肤经费",
                done: false
            }, {
                id: 2,
                todo: "晚上吃烧烤",
                done: true
            }
        ]
    }
    // state 是个不可变值，不要直接修改 state ，而是根据原有 state 返回一个新值
    addTodo = (todo) => {
        const { todos } = this.state;
        this.setState({
            todos: [
                {
                    id: Date.now(),
                    todo,
                    done: false
                },
                ...todos
            ]
        })
    }
    changeDone = (id, done) => {
        const { todos } = this.state;
        this.setState({
            todos: todos.map(item=>{
                if(id === item.id){
                    return {
                        ...item,
                        done
                    }
                }
                return item;
            })
        })
    }
    removeTodo = (id) => {
        const { todos } = this.state;
        this.setState({
            todos: todos.filter(item => (item.id !== id))
        })
    }
    render() {
        const { todos } = this.state;
        return <div id="todoapp">
            <div className="title">
                <h1>todo</h1>
            </div>
            <div className="content">
                <CreateTodo
                    addTodo={this.addTodo}
                />
                {todos.length > 0 ? <>
                    <Todos
                        data={todos}
                        changeDone={this.changeDone}
                        removeTodo={this.removeTodo}
                    />,
                    <Stats
                        data={todos}
                    />
                </> : ""}

            </div>
        </div>
    }
}

export default App;
