import {Button} from "antd";
function App(){
  return <>
    <Button type="primary">按钮</Button>
  </>
}

export default App;
