import Child1 from "./child1";
import Child2 from "./child2";
function App(){
  return <>
      <Child1 />
      <Child2 />
  </>
}

export default App;
