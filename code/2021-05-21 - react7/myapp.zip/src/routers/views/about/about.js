function AboutView(){
  return <div>
    <h1>关于</h1>
  </div>
}
export default AboutView;