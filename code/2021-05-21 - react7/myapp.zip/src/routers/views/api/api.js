function APIView(){
  return <div>
    <h1>API</h1>
  </div>
}
export default APIView;