function GetStartView(){
  return <div>
    <h1>新手入门</h1>
  </div>
}
export default GetStartView;