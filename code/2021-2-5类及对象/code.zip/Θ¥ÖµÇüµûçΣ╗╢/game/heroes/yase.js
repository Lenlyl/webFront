export default class Yase{
    constructor(){
        this.name = "亚瑟1";
        this.ico = "./sources/heroes/yase1.png";
        this.skills = [];
    }
} 